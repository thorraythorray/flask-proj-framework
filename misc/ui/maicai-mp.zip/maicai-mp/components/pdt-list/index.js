Component({
  properties: {
    list: {
      type: Array,
      value: []
    },
    isNoMore: Boolean
  }
})