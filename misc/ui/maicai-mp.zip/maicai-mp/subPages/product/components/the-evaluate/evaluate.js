Component({
  properties: {
    info: Object,
    less: Boolean
  }
})